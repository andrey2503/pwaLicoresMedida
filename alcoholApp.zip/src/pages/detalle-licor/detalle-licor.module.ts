import { NgModule } from '@angular/core';
// import { IonicPageModule } from 'ionic-angular';
// import { DetalleLicorPage } from './detalle-licor';

@NgModule({
  declarations: [
    // DetalleLicorPage,
  ],
  imports: [
    // IonicPageModule.forChild(DetalleLicorPage),
  ],
})
export class DetalleLicorPageModule {}
